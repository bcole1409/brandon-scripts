import pendulum


def past_3_bus_days():
    if pendulum.today().subtract(days=1).weekday() == 6:
        return pendulum.today().subtract(days=5).date()

    if pendulum.today().subtract(days=1).weekday() == 5:
        return pendulum.today().subtract(days=4).date()

    return pendulum.today().subtract(days=3).date()


def today_date():
    return pendulum.today().date()


def prev_trade_date():
    return pendulum.today().subtract(days=1) .date()if pendulum.today().subtract(days=1).date().weekday() <= 4 else pendulum.today().subtract(days=4).date()


def first_day_of_curr_month(date):
    return date.start_of('month')


def first_day_3_month_ago(date):
    return date.subtract(months=3).start_of('month')
