from common.databases.utils import get_sql_script
import settings as cfg
import pandas as pd
from sqlalchemy.engine import URL
from sqlalchemy import create_engine

rec_date = '2022-12-01'


def main():
    res = pd.DataFrame()

    cab_query = get_sql_script('t_bill_coverage_account_bond.sql', 'common/databases/queries', params={
        'rec_date': rec_date
    })

    long_query = get_sql_script('t_bill_long_bond.sql', 'common/databases/queries', params={
        'rec_date': rec_date
    })

    connection_string = cfg.get_database_conn(cfg.SQL_DRIVER, cfg.RTPL_SERVER, 'Clearing', cfg.OPS_SQL_USER,
                                              cfg.OPS_SQL_PASSWORD)
    connection_url = URL.create("mssql+pyodbc", query={"odbc_connect": connection_string})
    engine = create_engine(connection_url)

    df = pd.read_sql(cab_query, engine)

    res = pd. concat([])

    print(df)


if __name__ == "__main__":
    main()
