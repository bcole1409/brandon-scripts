DECLARE @CurrentDate datetime;
DECLARE @threemonths datetime;
SET @CurrentDate = '{{start_date}}'
SET @threemonths = DATEADD(MONTH, DATEDIFF(MONTH, 0, @CurrentDate)-2, 0)

SELECT * FROM [Risk].[dbo].[daily_ifmReport] Where FillTimeStamp >= @threemonths
and ex = 'CME'
and base in {{product_list}}