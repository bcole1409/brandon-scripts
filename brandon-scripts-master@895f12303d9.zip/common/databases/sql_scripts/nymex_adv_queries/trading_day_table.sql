SET NOCOUNT ON SET ANSI_WARNINGS OFF
  DECLARE @CurrentDate datetime;
  DECLARE @threemonths datetime;
  DECLARE @Endthreemonths datetime;
  DECLARE @CurrentMonth datetime;
  DECLARE @DateCount int;
  DECLARE @threemonthDateCount int;
  DECLARE @total_tradedays integer;
  DECLARE @remain_tradedays integer;

CREATE TABLE ##TEMPVOL
  (TradingGroup varchar(30),
  Product varchar(2),
  SessionDate Date,
  TotalVolume float);

  SET @CurrentDate = '{{prev_date}}'
  SET @threemonths = DATEADD(MONTH, DATEDIFF(MONTH, 0, @CurrentDate)-2, 0)
  INSERT INTO ##TEMPVOL

  SELECT
  gr.[TgName] as [TradingGroup]
  ,LEFT(eod.[EodSymbol],2) as Product
  ,eod.[EodSessionDate] as SessionDate
  ,TotalVolume = SUM((ABS(eod.[EodBuyVolume])+ABS(eod.[EodSellVolume])))
  FROM [RTPL].[dbo].[EodPLSummary] eod
  LEFT JOIN [People].[dbo].[TradeGroup] gr
  ON eod.TgId = gr.TgId
  LEFT JOIN [Products].[dbo].[Product] pr
  ON eod.[EodSymbol] = pr.PrdSymbol
  LEFT JOIN [Products].[dbo].[ProductMaster] pm
  ON pm.PmId = pr.PmId
  WHERE EodSessionDate >= @threemonths
  AND EodSessionDate not in (select WecDate from [Common].[dbo].[WorldEventCalendar] where WecCode = 'NM' AND WecSettle = 'No')  -- FACTORS IN HOLIDAYS
  AND EodSessionDate <= @CurrentDate
  AND eod.FtypId = '8'
  AND LEFT(EodSymbol,2) IN ('CL','HO','NG','RB','BZ','HH')
  AND EodSymbol NOT LIKE 'RBB%'
  AND eod.[TacComments] NOT LIKE '%TRANSFER%'
  AND pr.[PrdIsSpread] = '0'
  AND gr.[TgName] <> 'GEM'
  AND eod.ExcId <> 16 --Exclude exhchange of Intertal
  GROUP BY
  LEFT(EodSymbol,2),
  gr.[TgName],
  eod.[EodSessionDate]




  SET @CurrentDate = (select max(SessionDate) from ##TEMPVOL);
  SET @threemonths = DATEADD(MONTH, DATEDIFF(MONTH, 0, @CurrentDate)-2, 0)
  SET @Endthreemonths= DATEADD(MONTH, DATEDIFF(MONTH, 0,@CurrentDate)+1, -1)
  SET @CurrentMonth = DATEADD(month, DATEDIFF(month, 0, @CurrentDate), 0);
  SET @DateCount = (select count(*) from (select distinct SessionDate from ##TEMPVOL where SessionDate >=@CurrentMonth AND SessionDate <= @CurrentDate) as tab);
  SET @threemonthDateCount = (select count(*) from (select distinct SessionDate from ##TEMPVOL where SessionDate >=@threemonths AND SessionDate <= @CurrentDate) as tab);
  SET @total_tradedays =  (DATEDIFF(dd, @threemonths, @Endthreemonths) + 1)
  -(DATEDIFF(wk, @threemonths, @Endthreemonths) * 2)
  -(CASE WHEN DATEPART(dw, @threemonths) = 1 THEN 1 ELSE 0 END)
  -(CASE WHEN DATEPART(dw, @Endthreemonths) = 7 THEN 1 ELSE 0 END)
  -(select count(*) from [Common].[dbo].[WorldEventCalendar]
  where WecCode = 'NM' and WecSettle = 'No' and (WecDate BETWEEN @threemonths AND @Endthreemonths))
  SET @remain_tradedays =  (DATEDIFF(dd, @CurrentDate+1, @Endthreemonths) + 1)
  -(DATEDIFF(wk, @CurrentDate+1, @Endthreemonths) * 2)
  -(CASE WHEN DATEPART(dw, @CurrentDate+1) = 1 THEN 1 ELSE 0 END)
  -(CASE WHEN DATEPART(dw, @Endthreemonths) = 7 THEN 1 ELSE 0 END)
  -(select count(*) from [Common].[dbo].[WorldEventCalendar]
  where WecCode = 'NM' and WecSettle = 'No' and (WecDate BETWEEN @CurrentDate+1 AND @Endthreemonths))
  SET NOCOUNT OFF;

  SELECT 'DateCount' AS VARIABLE, @DateCount AS VALUE
  UNION ALL
  SELECT 'threemonthDateCount' AS VARIABLE, @threemonthDateCount AS VALUE
  UNION ALL
  SELECT 'total_tradedays' AS VARIABLE, @total_tradedays AS VALUE
  UNION ALL
  SELECT 'remain_tradedays' AS VARIABLE, @remain_tradedays AS VALUE

 Drop Table ##TEMPVOL