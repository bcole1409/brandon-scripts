import sys
import pathlib

try:
    from common.databases.utils import get_sql_script
    from common.services.email_service import emailer
    import common.services.date_service as dates


except Exception as e:
    project_root = pathlib.Path(__file__).parent.parent.resolve()
    sys.path.append(str(project_root))
    from common.databases.utils import get_sql_script
    from common.services.email_service import emailer
    import common.services.date_service as dates

import pandas as pd
import settings as cfg

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 200)

product_list = "('CL','HO','NG','RB','BZ','HH')"


def format_vol_col(col_name, df):
    for col in col_name:
        df[col] = df.apply(lambda row: "{:,.0f}".format(int(row[col])), axis=1)
    # df = df.style.set_properties(**{'background-color': '#ffffb3'}, subset=['Product', col_name])

    return df


def get_html_body(daily_df, monthly_df, three_month_df, target_df):
    html = f"""
        <html>
        <head></head>
        <body>
            <div>
            <h3><strong>Daily Volume: </strong>
            </div>
            {daily_df.to_html(index=False).replace('<td>', '<td align="right">')}
            </div>
            <h3><strong>Monthly ADV: </strong>
            {monthly_df.to_html(index=False).replace('<td>', '<td align="right">')}
            </div>
            <h3><strong>3-Month ADV: </strong>
            {three_month_df.to_html(index=False).replace('<td>', '<td align="right">')}
            </div>
            <h3><strong>Volume Needed: </strong>
            {target_df.to_html(index=False).replace('<td>', '<td align="right">')}
            </div>
        </body>
        </html>
        """
    return html


def get_self_match_agg(sm):
    res = []
    # TODO -> is there a better algo for this?
    self_match_df = sm.to_dict('records')
    for row in self_match_df:
        list_of_products = row['PrdSymbol'].split('-')  # if - we need to split into legs
        for product in list_of_products:
            prod_abbr = product[:-2]  # remove right char's == Month Year code
            entry = {'SessionDate': row['Date'], 'Product': prod_abbr, 'TotalVolume': row[
                                                                                          'Quantity'] * -1}  # adding negative, so we subtract out later on when we're adding
            res.append(entry)

    return pd.DataFrame(res)


def get_daily_adv(prev_date, rtpl_trades, block_trades, self_match):
    daily_rtpl_df = rtpl_trades.query("SessionDate == @prev_date")
    daily_block_df = block_trades.query("SessionDate == @prev_date")
    self_match_df = self_match.query("SessionDate == @prev_date")

    daily_rtpl_df = daily_rtpl_df.groupby(['SessionDate', 'Product'])['TotalVolume'].sum().reset_index()
    daily_block_df = daily_block_df.groupby(['SessionDate', 'Product'])['TotalVolume'].sum().reset_index()
    self_match_df = self_match_df.groupby(['SessionDate', 'Product'])['TotalVolume'].sum().reset_index()

    daily_vol = daily_rtpl_df[['Product', 'TotalVolume']].merge(daily_block_df[['Product', 'TotalVolume']],
                                                                on='Product', how='left').merge(
        self_match_df[['Product', 'TotalVolume']], on='Product', how='left').fillna(0)

    daily_vol['Daily Volume'] = daily_vol.apply(
        lambda row: int(row.TotalVolume_x + row.TotalVolume_y + row.TotalVolume), axis=1)
    daily_vol_df = daily_vol[['Product', 'Daily Volume']]

    # add ng_hh and cl_ho_rb
    add_vol = [
        {'Product': 'NG_HH', 'Daily Volume': daily_vol_df.query("Product in ('NG', 'HH')")['Daily Volume'].sum()},
        {'Product': 'CL_HO_RB',
         'Daily Volume': daily_vol_df.query("Product in ('CL', 'HO', 'RB')")['Daily Volume'].sum()}]

    daily_vol_df = pd.concat([daily_vol_df.sort_values('Product'),
                              pd.DataFrame(add_vol, columns=['Product', 'Daily Volume']).sort_values('Product')])

    return daily_vol_df[['Product', 'Daily Volume']]


def get_monthly_adv(first_day_of_month, prev_day, trade_day_count, rtpl_trades, block_trades, self_match_trades):
    monthly_rtpl_df = rtpl_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")
    monthly_block_df = block_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")
    monthly_self_match_df = self_match_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")

    monthly_rtpl_df = monthly_rtpl_df.groupby(['Product'])['TotalVolume'].sum().reset_index()
    monthly_block_df = monthly_block_df.groupby(['Product'])['TotalVolume'].sum().reset_index()
    monthly_self_match_df = monthly_self_match_df.groupby(['Product'])['TotalVolume'].sum().reset_index()

    monthly_vol = monthly_rtpl_df[['Product', 'TotalVolume']].merge(monthly_block_df[['Product', 'TotalVolume']],
                                                                    on='Product', how='left').merge(
        monthly_self_match_df[['Product', 'TotalVolume']],
        on='Product', how='left').fillna(0)

    monthly_vol['Monthly ADV'] = monthly_vol.apply(
        lambda row: int((row.TotalVolume_x + row.TotalVolume_y + row.TotalVolume) / trade_day_count), axis=1)

    # add ng_hh and cl_ho_rb
    add_vol = [
        {'Product': 'NG_HH',
         'Monthly ADV': monthly_vol[['Product', 'Monthly ADV']].query("Product in ('NG', 'HH')")['Monthly ADV'].sum()},
        {'Product': 'CL_HO_RB',
         'Monthly ADV': monthly_vol.query("Product in ('CL', 'HO', 'RB')")['Monthly ADV'].sum()}]

    monthly_vol_df = pd.concat([monthly_vol[['Product', 'Monthly ADV']].sort_values('Product'),
                                pd.DataFrame(add_vol, columns=['Product', 'Monthly ADV']).sort_values('Product')])

    return monthly_vol_df[['Product', 'Monthly ADV']]


def get_3_month_adv(first_day_3_month_ago, prev_day, trade_day_count, rtpl_trades, block_trades, self_match_trades):
    monthly_rtpl_df = rtpl_trades.query("SessionDate >= @first_day_3_month_ago & SessionDate <= @prev_day")
    monthly_block_df = block_trades.query("SessionDate >= @first_day_3_month_ago & SessionDate <= @prev_day")
    monthly_self_match_df = self_match_trades.query("SessionDate >= @first_day_3_month_ago & SessionDate <= @prev_day")

    monthly_rtpl_df = monthly_rtpl_df.groupby(['Product'])['TotalVolume'].sum().reset_index()
    monthly_block_df = monthly_block_df.groupby(['Product'])['TotalVolume'].sum().reset_index()
    monthly_self_match_df = monthly_self_match_df.groupby(['Product'])['TotalVolume'].sum().reset_index()

    monthly_vol = monthly_rtpl_df[['Product', 'TotalVolume']].merge(monthly_block_df[['Product', 'TotalVolume']],
                                                                    on='Product', how='left').merge(
        monthly_self_match_df[['Product', 'TotalVolume']],
        on='Product', how='left').fillna(0)

    monthly_vol['3 Month ADV'] = monthly_vol.apply(
        lambda row: int((row.TotalVolume_x + row.TotalVolume_y + row.TotalVolume) / trade_day_count), axis=1)

    # add ng_hh and cl_ho_rb
    add_vol = [
        {'Product': 'NG_HH',
         '3 Month ADV': monthly_vol[['Product', '3 Month ADV']].query("Product in ('NG', 'HH')")['3 Month ADV'].sum()},
        {'Product': 'CL_HO_RB',
         '3 Month ADV': monthly_vol.query("Product in ('CL', 'HO', 'RB')")['3 Month ADV'].sum()}]

    monthly_vol_df = pd.concat([monthly_vol[['Product', '3 Month ADV']].sort_values('Product'),
                                pd.DataFrame(add_vol, columns=['Product', '3 Month ADV']).sort_values('Product')])

    return monthly_vol_df[['Product', '3 Month ADV']]


def get_needed_adv(total_trade_days, prev_day, trade_day_count, rtpl_trades, block_trades, self_match_trades):
    mapping_table = [{'Product': ['BZ'], 'Program': 'BZ_CL_RB', '3-Month ADV': 5000, 'Volume Requirement': trade_day_count * 5000, 'Total Volume': 0, 'Volume Needed': 0},
                     {'Product': ['NG', 'HH'], 'Program': 'Level 1 Nat Gas', '3-Month ADV': 5000, 'Volume Requirement': trade_day_count * 5000, 'Total Volume': 0, 'Volume Needed': 0},
                     {'Product': ['NG', 'HH'], 'Program': 'Level 2 Nat Gas', '3-Month ADV': 15000, 'Volume Requirement': trade_day_count * 15000, 'Total Volume': 0, 'Volume Needed': 0},
                     {'Product': ['CL', 'HO', 'RB'], 'Program': 'Level 1 CL_HO_RB', '3-Month ADV': 15000, 'Volume Requirement': trade_day_count * 15000, 'Total Volume': 0, 'Volume Needed': 0},
                     {'Product': ['CL', 'HO', 'RB'], 'Program': 'Level 2 CL_HO_RB', '3-Month ADV': 45000, 'Volume Requirement': trade_day_count * 45000, 'Total Volume': 0, 'Volume Needed': 0}]

    for program in mapping_table:
        filter_product_list = program['Product']
        filter_rtpl_trades = rtpl_trades.query("Product in @filter_product_list")
        filter_block_trades =block_trades.query("Product in @filter_product_list")
        filter_self_match_trades = self_match_trades.query("Product in @filter_product_list")

        rtpl_trade_count = filter_rtpl_trades.groupby(['Product'])['TotalVolume'].sum().reset_index()
        rtpl_block_trade_count = filter_block_trades.groupby(['Product'])['TotalVolume'].sum().reset_index()
        rtpl_self_match_trade_count = filter_self_match_trades.groupby(['Product'])['TotalVolume'].sum().reset_index()

        volume_total_df = rtpl_trade_count[['Product', 'TotalVolume']].merge(rtpl_block_trade_count[['Product', 'TotalVolume']],
                                                                        on='Product', how='left').merge(
            rtpl_self_match_trade_count[['Product', 'TotalVolume']],
            on='Product', how='left').fillna(0)

        volume_total_df['Total Volume'] = volume_total_df.apply(
            lambda row: int((row.TotalVolume_x + row.TotalVolume_y + row.TotalVolume)), axis=1)

        program['Total Volume'] = volume_total_df['Total Volume'].sum()
        program['Volume Needed'] = 0 if program['Volume Requirement'] - program['Total Volume'] <= 0 else program['Volume Requirement'] - program['Total Volume']

    return pd.DataFrame(mapping_table)[['Program', 'Volume Requirement', 'Total Volume', 'Volume Needed']]


def run():
    ###################################################
    #               Start - Date Logic                #
    ###################################################
    # prev_trade_date = dates.prev_trade_date()
    import pendulum
    prev_trade_date = pendulum.date(2023, 1, 24)
    td_query = get_sql_script('trading_day_table.sql', 'common/databases/sql_scripts/nymex_adv_queries', params={
        'prev_date': prev_trade_date
    })

    db_engine = cfg.get_database_engine(driver='{ODBC Driver 17 for SQL Server}',
                                        server=cfg.RTPL_SERVER,
                                        database='Common',
                                        user=cfg.OPS_SQL_USER,
                                        password=cfg.OPS_SQL_PASSWORD)

    td_df = pd.read_sql(td_query, db_engine).set_index('VARIABLE').to_dict('index')
    DATE_COUNT = td_df['DateCount']['VALUE']
    THREE_MONTH_DATE_COUNT = td_df['threemonthDateCount']['VALUE']
    TOTAL_TRADE_DAYS = td_df['total_tradedays']['VALUE']
    REMAINING_TRADE_DAYS = td_df['remain_tradedays']['VALUE']
    print(
        f'DATE_COUNT {DATE_COUNT}\nTHREE_MONTH_DATE_COUNT {THREE_MONTH_DATE_COUNT}\nTOTAL_TRADE_DAYS {TOTAL_TRADE_DAYS}\nREMAINING_TRADE_DAYS {REMAINING_TRADE_DAYS}')
    #               End - Date Logic                  #
    ###################################################
    ###################################################
    #               Start - Self Match                #
    self_match_query = get_sql_script('self_match_vol.sql', 'common/databases/sql_scripts/nymex_adv_queries', params={
        'start_date': prev_trade_date,
        'product_list': product_list
    })

    db_engine = cfg.get_database_engine(driver='{ODBC Driver 17 for SQL Server}',
                                        server=cfg.OPS_SERVER,
                                        database='Risk',
                                        user=cfg.OPS_SQL_USER,
                                        password=cfg.OPS_SQL_PASSWORD)
    self_match_df = get_self_match_agg(pd.read_sql(self_match_query, db_engine))

    #               End - Self Match                  #
    ###################################################
    ###################################################
    #               Start - Trade Data                #
    rtpl_trades_query = get_sql_script('rtpl_trades.sql', 'common/databases/sql_scripts/nymex_adv_queries', params={
        'prev_date': prev_trade_date,
        'product_list': product_list
    })

    block_trades_query = get_sql_script('block_trades.sql', 'common/databases/sql_scripts/nymex_adv_queries', params={
        'prev_date': prev_trade_date,
        'product_list': product_list
    })

    db_engine = cfg.get_database_engine(driver='{ODBC Driver 17 for SQL Server}',
                                        server=cfg.RTPL_SERVER,
                                        database='RTPL',
                                        user=cfg.OPS_SQL_USER,
                                        password=cfg.OPS_SQL_PASSWORD)

    rtpl_df = pd.read_sql(rtpl_trades_query, db_engine).sort_values(by='SessionDate', ascending=False)
    block_df = pd.read_sql(block_trades_query, db_engine).sort_values(by='SessionDate', ascending=False)

    rtpl_df['SessionDate'] = pd.to_datetime(rtpl_df['SessionDate'], format='%Y-%m-%d')
    block_df['SessionDate'] = pd.to_datetime(block_df['SessionDate'], format='%Y-%m-%d')

    ###################################################
    #               End - Trade Data                  #
    ###################################################

    #
    """
    Obligations:
    - Nat Gas
        - Level 1 -> 3 month-rolling average - 5,000 adv
        - Level 2 -> 3 month-rolling average - 15,000 adv
    """

    ###################################################
    #           Table Metrics - Email Body            #
    ###################################################
    daily_adv = format_vol_col(['Daily Volume'], get_daily_adv(prev_trade_date, rtpl_df, block_df, self_match_df))
    monthly_adv = format_vol_col(['Monthly ADV'],
                                 get_monthly_adv(dates.first_day_of_curr_month(prev_trade_date), prev_trade_date,
                                                 DATE_COUNT,
                                                 rtpl_df, block_df, self_match_df))
    three_month_adv = format_vol_col(['3 Month ADV'],
                                     get_3_month_adv(dates.first_day_3_month_ago(prev_trade_date), prev_trade_date,
                                                     THREE_MONTH_DATE_COUNT,
                                                     rtpl_df, block_df, self_match_df))

    needed_volume = format_vol_col(['Volume Requirement', 'Total Volume', 'Volume Needed'], get_needed_adv(dates.first_day_3_month_ago(prev_trade_date), prev_trade_date,
                                                     THREE_MONTH_DATE_COUNT,
                                                     rtpl_df, block_df, self_match_df))

    emailer(f'THIS IS A TEST YO - NYMEX Volume Report: {prev_trade_date}', get_html_body(daily_adv, monthly_adv, three_month_adv, needed_volume),
            ['bcole', 'vracke'])


if __name__ == "__main__":
    run()
