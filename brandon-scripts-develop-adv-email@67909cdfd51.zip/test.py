import pandas as pd
import numpy as np


# Create a Pandas Excel writer using XlsxWriter as the engine.
writer = pd.ExcelWriter(r'C:\Users\bcole\Desktop\SOFR Margin Scenarios.xlsx', engine='xlsxwriter')

df = pd.read_csv(r'C:\Users\bcole\Desktop\template.csv')
scenarios = df['Scenario Name'].unique()

for scenario in scenarios:
    if scenario is not np.nan:
        temp_df = df.apply(lambda row: row[df['Scenario Name'] == scenario])
        temp_df['Expiry'] = temp_df['Expiry'].astype('int64')
        temp_df = temp_df[['Expiry', 'Quantity', 'Total Difference']].sort_values(by=['Expiry','Quantity'])
        pivot_df = temp_df.pivot(index='Expiry', columns='Quantity', values='Total Difference')
        pivot_df.to_excel(writer, sheet_name=f'{scenario}')

        # Apply a conditional format to the required cell range.
        worksheet = writer.sheets[f'{scenario}']
        max_col = len(pivot_df.columns)
        max_row = len(pivot_df)
        quantiles_1 = np.quantile(temp_df[['Total Difference']], 0.1)
        # quantiles_2 = np.quantile(temp_df[['Total Difference']], 0.50) -> dont need mid
        quantiles_3 = np.quantile(temp_df[['Total Difference']], 0.7)

        worksheet.conditional_format(1, 1, max_row, max_col,
                                     {'type': '3_color_scale',
                                      'min_color': "green",
                                      'min_type': 'num',
                                      'min_value': quantiles_1,  # 'min_value': -1_000_000,
                                      'mid_color': "yellow",
                                      'mid_value': 0,
                                      'mid_type': 'num',
                                      'max_color': "red",
                                      'max_value': quantiles_3,  # 'max_value': 3_000_000,
                                      'max_type': 'num',
                                      })

        workbook = writer.book
        num_format = workbook.add_format({'num_format': '#,###'})
        width = 12
        unique_quantities = len(pivot_df.columns)
        worksheet.set_column(1, unique_quantities, width, num_format)


# close will stop from writing and create the workbook
writer.close()
