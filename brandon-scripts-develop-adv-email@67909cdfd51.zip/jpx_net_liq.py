import sys
import pathlib

try:
    from common.databases.utils import get_sql_script
    from common.services.email_service import emailer


except Exception as e:
    project_root = pathlib.Path(__file__).parent.parent.resolve()
    sys.path.append(str(project_root))
    from common.databases.utils import get_sql_script
    from common.services.email_service import emailer

import pendulum
import pandas as pd
import settings as cfg
from sqlalchemy.engine import URL, create_engine

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 200)

connection_string = cfg.get_database_conn(driver='{ODBC Driver 17 for SQL Server}',
                                          server=cfg.RTPL_SERVER,
                                          database='Clearing',
                                          user=cfg.OPS_SQL_USER,
                                          password=cfg.OPS_SQL_PASSWORD)

connection_url = URL.create("mssql+pyodbc", query={"odbc_connect": connection_string})
engine = create_engine(connection_url)


def agg_df(df):
    return df.groupby(['SessionDate', 'AccountID'])['NetLiq'].sum().reset_index()


def run():
    us_jpx_net_liq_query = get_sql_script('abn_us_data.sql', 'common/databases/sql_scripts/jpx_net_queries', params={
        'start_date': pendulum.today().subtract(days=7).strftime("%Y-%m-%d")
    })

    uk_jpx_net_liq_query = get_sql_script('abn_uk_data.sql', 'common/databases/sql_scripts/jpx_net_queries', params={
        'start_date': pendulum.today().subtract(days=7).strftime("%Y-%m-%d")
    })

    ccy_rates_query = get_sql_script('ccy_rate_query.sql', 'common/databases/sql_scripts/ccy_rates_queries', params={
        'start_date': pendulum.today().subtract(days=7).strftime("%Y-%m-%d")
    })

    abn_us_df = pd.read_sql(us_jpx_net_liq_query, engine)
    abn_uk_df = pd.read_sql(uk_jpx_net_liq_query, engine)
    ccy_rates_df = pd.read_sql(ccy_rates_query, engine)

    abn_us_df = agg_df(abn_us_df)
    abn_uk_df = agg_df(abn_uk_df)
    abn_uk_df = abn_uk_df.merge(ccy_rates_df, on='SessionDate', how='left')
    abn_us_df['NetLiq'] = abn_us_df.apply(lambda row: "{:,.2f}".format(round(row.NetLiq,2)), axis=1)
    abn_uk_df['Converted_NetLiq_USD'] = abn_uk_df.apply(lambda row: "{:,.2f}".format(round(row.NetLiq * row.CcyRateToUsd, 2)), axis=1)
    abn_uk_df = abn_uk_df[['SessionDate', 'AccountID', 'Converted_NetLiq_USD']]

    html = f"""
    <html>
    <head></head>
    <body>
        <div>
        <h3><strong>ABN US NetLiq: 87679</strong>
        </div>
        {abn_us_df.to_html(index=False)}
        <h3><strong>ABN UK NetLiq: DB231</strong>
        {abn_uk_df.to_html(index=False)}
        </div>
    </body>
    </html>
    """
    emailer("GTM: CME/JPX NetLiq Tracker", html, ['bcole', 'vracke'])


if __name__ == "__main__":
    run()
