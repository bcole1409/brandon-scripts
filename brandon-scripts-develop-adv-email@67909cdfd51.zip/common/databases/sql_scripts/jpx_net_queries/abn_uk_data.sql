Declare @StartDate date
Set @StartDate = '{{start_date}}'

Select SessionDate, concat('DB', [AccountId]) as AccountID, Currency, OpeningBalance as NetLiq

FROM [Clearing].[dbo].[ABNUK_MICS_CASHSUMMRYACCNTLVL]
  WHERE SessionDate >= @StartDate
  AND AccountId = '238'
  ANd Deleted = '0'

