Declare @StartDate date
Set @StartDate = '{{start_date}}'


SELECT [FilId],
		[PrdId],
		[FilExtrnlAccountId] as Account
        ,[FilExchangeTradeId] as TradeId,[FilExchangeOrderId] as OrderId,[FilExchangeFillId] as FillId
		,[FilQuantity] as Quantity,[FilPrice] as Price,[FilDirectFee] as Fee
        ,[FilMessage] as Message
        --,[FilFillTimeStamp] as TimeStamp
        ,[FilSessionDate] as SessionDate
      ,[FilTradeSessionDate] as TradeSessionDate
      --,[FilAsOfDate]
      ,[FilLoadTime] as LoadTime
  FROM [TradeCapture].[dbo].[Fill]
  Where FilCancelledFlg = 0
    AND FilLoadTime >= @StartDate
    and FtypId = '2'
    and FilExchangeTradeId not like '%TAS_CONV%'