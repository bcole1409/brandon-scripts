import pandas as pd
import pyodbc as db
import smtplib
import common.services.date_service as dates
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import COMMASPACE, formatdate


def email(df, recipients):
    list_of_emails = [user + '@genevatrading.com' for user in recipients]

    msg = MIMEMultipart()
    msg['From'] = "operations1@genevatrading.com"
    msg['To'] = COMMASPACE.join(list_of_emails)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = f"GTM CME/JPX NetLiq Report - {dates.today_date()}"

    html = f"""\
                <html>
                <head></head>
                <body>
                    <div>
                    <h3><strong>Failed to insert the following:</strong>
                    </div>
                    {df.to_html(index= False)}
                </body>
                </html>
                """

    part1 = MIMEText(html, 'html')
    msg.attach(part1)

    smtp = smtplib.SMTP(host='smtp-mail.outlook.com', port=587)
    smtp.starttls()
    smtp.login("operations1@genevatrading.com", 'G3n3v@ops')
    smtp.send_message(msg)
    smtp.close()


def emailer(email_subject: str, html_body: str, recipients: list[str]):
    list_of_emails = [user + '@genevatrading.com' for user in recipients]

    msg = MIMEMultipart()
    msg['From'] = "operations1@genevatrading.com"
    msg['To'] = COMMASPACE.join(list_of_emails)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = f"{email_subject} - {dates.today_date()}"

    html = html_body

    part1 = MIMEText(html, 'html')
    msg.attach(part1)

    smtp = smtplib.SMTP(host='smtp-mail.outlook.com', port=587)
    smtp.starttls()
    smtp.login("operations1@genevatrading.com", 'G3n3v@ops')
    smtp.send_message(msg)
    smtp.close()
