# scheduled scripts
import rtpl_manual_trade_date_checker as rtpl_trade_date_checker_process

from apscheduler.schedulers.background import BlockingScheduler
import tzlocal
import settings

jobs = [
    {'job_name': 'rtpl_trade_date_checker', 'job_entry': rtpl_trade_date_checker_process, 'schedule_type': 'cron', 'day_of_week': 'mon-fri', 'hour': 2, 'minute': 0}
]


def main():
    rtpl_trade_date_checker_process.run()

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    if settings.run_jobs_in_scheduler:
        # system_load()
        sched = BlockingScheduler(timezone=str(tzlocal.get_localzone()))
        for job in jobs:
            sched.add_job()
            sched.add_job(job['job_entry'].run,
                          job['schedule_type'],
                          day_of_week=job['day_of_week'],
                          hour=job['hour'],
                          minute=job['minute'])
        sched.start()
    else:
        main()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
