import pathlib
import jinja2

scripts_path = pathlib.Path(__file__).parent.parent.parent.absolute()


def get_sql_script(script_name, path, params: dict = None):
    """
    grab static script
    :return:
    """
    sql_dir = scripts_path.joinpath(f'{path}')
    tmpl_loader = jinja2.FileSystemLoader(sql_dir)
    sql = jinja2.Environment(loader=tmpl_loader)
    if params is None:
        return sql.get_template(script_name).render()
    return sql.get_template(script_name).render(params)
