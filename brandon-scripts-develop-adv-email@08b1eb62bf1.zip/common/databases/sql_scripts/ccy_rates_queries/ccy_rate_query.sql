SELECT
      [CcySessionDate] as SessionDate, [CcyTag], [CcyRateToUsd]
  FROM [Products].[dbo].[CurrencyDailyRate]
   Where CcySessionDate >= '{{start_date}}'
    and CcyTag = 'JPY'