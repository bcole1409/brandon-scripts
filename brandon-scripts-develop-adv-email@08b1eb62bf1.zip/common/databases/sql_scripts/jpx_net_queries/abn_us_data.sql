Declare @StartDate date
Set @StartDate = '{{start_date}}'

Select SessionDate
    ,right(AccountName,5) as AccountID
    ,sum(OpeningBalance) As NetLiq

FROM [Clearing].[dbo].[ABNUS_MICS_CSVCASH_AC]
Where AccountId = '7679'
AND SessionDate >= @StartDate
AND Deleted = '0'
AND CashTitle NOT like ('MARGIN%')



Group by AccountName,SessionDate