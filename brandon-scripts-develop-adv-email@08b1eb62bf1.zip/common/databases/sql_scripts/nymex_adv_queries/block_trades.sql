---- SUBTRACT OUT BLOCK TRADES ---
  SET NOCOUNT ON;
  DECLARE @CurrentDate datetime;
  DECLARE @threemonths datetime;
  SET @CurrentDate = CONVERT(DATETIME, '{{prev_date}}');
  SET @threemonths = DATEADD(MONTH, DATEDIFF(MONTH, 0, @CurrentDate)-2, 0);
  SET NOCOUNT OFF;

  (SELECT
  [ProductCode] AS Product
  ,[TradeDate] as SessionDate
  --,InputSource AS TradeType
  ,SUM(CASE WHEN [TradeReportTransType] = '1' THEN (TradeQuantity*1) ELSE TradeQuantity*-1 END) AS TotalVolume
  FROM [RhoneBackOffice].[dbo].[RawCMEFills]
  WHERE TradeDate >= @threemonths
  AND ProductExchange = 'NYMEX'
  AND InputSource = 'CPC'
  AND [ProductCode] in {{product_list}}
  AND SecurityType ='FUT'
  AND PriceType!=100
  And InputSource  <> 'FIRM'

  GROUP BY ProductCode, TradeDate)
