SET NOCOUNT ON SET ANSI_WARNINGS OFF

CREATE TABLE ##TEMPVOL
  (TradingGroup varchar(30),
  Product varchar(2),
  SessionDate Date,
  TotalVolume float);
  DECLARE @CurrentDate datetime;
  DECLARE @threemonths datetime;
  SET @CurrentDate = '{{prev_date}}'
  SET @threemonths = DATEADD(MONTH, DATEDIFF(MONTH, 0, @CurrentDate)-2, 0)


  INSERT INTO ##TEMPVOL

  SELECT
  gr.[TgName] as [TradingGroup]
  ,LEFT(eod.[EodSymbol],2) as Product
  ,eod.[EodSessionDate] as SessionDate
  ,TotalVolume = SUM((ABS(eod.[EodBuyVolume])+ABS(eod.[EodSellVolume])))
  FROM [RTPL].[dbo].[EodPLSummary] eod
  LEFT JOIN [People].[dbo].[TradeGroup] gr
  ON eod.TgId = gr.TgId
  LEFT JOIN [Products].[dbo].[Product] pr
  ON eod.[EodSymbol] = pr.PrdSymbol
  LEFT JOIN [Products].[dbo].[ProductMaster] pm
  ON pm.PmId = pr.PmId
  WHERE EodSessionDate >= @threemonths
  AND EodSessionDate not in (select WecDate from [Common].[dbo].[WorldEventCalendar] where WecCode = 'NM' AND WecSettle = 'No')  -- FACTORS IN HOLIDAYS
  AND EodSessionDate <= @CurrentDate
  AND eod.FtypId = '8'
  AND LEFT(EodSymbol,2) IN {{product_list}}
  AND EodSymbol NOT LIKE 'RBB%'
  AND eod.[TacComments] NOT LIKE '%TRANSFER%'
  AND pr.[PrdIsSpread] = '0'
  AND gr.[TgName] <> 'GEM'
  AND eod.ExcId <> 16 --Exclude exhchange of Intertal
  GROUP BY
  LEFT(EodSymbol,2),
  gr.[TgName],
  eod.[EodSessionDate]


Select * From ##TEMPVOL
drop table ##TEMPVOL