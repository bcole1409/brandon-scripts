import sys
import pathlib

try:
    from common.databases.utils import get_sql_script
    from common.services.email_service import emailer
    import common.services.date_service as dates


except Exception as e:
    project_root = pathlib.Path(__file__).parent.parent.resolve()
    sys.path.append(str(project_root))
    from common.databases.utils import get_sql_script
    from common.services.email_service import emailer
    import common.services.date_service as dates

import pandas as pd
import settings as cfg

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 200)

product_list = "('CL','HO','NG','RB','BZ','HH')"


def get_self_match_agg(sm):
    res = []
    # TODO -> is there a better algo for this?
    self_match_df = sm.to_dict('records')
    for row in self_match_df:
        list_of_products = row['PrdSymbol'].split('-')  # if - we need to split into legs
        for product in list_of_products:
            prod_abbr = product[:-2]  # remove right char's == Month Year code
            entry = {'SessionDate': row['Date'], 'Product': prod_abbr, 'TotalVolume': row['Quantity'] * -1} # adding negative, so we subtract out later on when we're adding
            res.append(entry)

    return pd.DataFrame(res)


def get_daily_adv(prev_date, rtpl_trades, block_trades, self_match):
    daily_rtpl_df = rtpl_trades.query("SessionDate == @prev_date")
    daily_block_df = block_trades.query("SessionDate == @prev_date")
    self_match_df = self_match.query("SessionDate == @prev_date")

    daily_rtpl_df = daily_rtpl_df.groupby(['SessionDate', 'Product'])['TotalVolume'].sum().reset_index()
    daily_block_df = daily_block_df.groupby(['SessionDate', 'Product'])['TotalVolume'].sum().reset_index()
    self_match_df = self_match_df.groupby(['SessionDate', 'Product'])['TotalVolume'].sum().reset_index()

    daily_vol = daily_rtpl_df[['Product', 'TotalVolume']].merge(daily_block_df[['Product', 'TotalVolume']],
                                                                on='Product', how='left').merge(
        self_match_df[['Product', 'TotalVolume']], on='Product', how='left').fillna(0)
    daily_vol['Daily Volume'] = daily_vol.apply(
        lambda row: int(row.TotalVolume_x + row.TotalVolume_y + row.TotalVolume), axis=1)
    daily_vol_df = daily_vol[['Product', 'Daily Volume']]
    return daily_vol_df


def get_monthly_adv(first_day_of_month, prev_day, trade_day_count, rtpl_trades, block_trades, self_match_trades):
    monthly_rtpl_df = rtpl_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")
    monthly_block_df = block_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")
    monthly_self_match_df = self_match_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")

    monthly_rtpl_df = monthly_rtpl_df.groupby(['Product'])['TotalVolume'].sum().reset_index()
    monthly_block_df = monthly_block_df.groupby(['Product'])['TotalVolume'].sum().reset_index()
    monthly_self_match_df = monthly_self_match_df.groupby(['Product'])['TotalVolume'].sum().reset_index()

    monthly_vol = monthly_rtpl_df[['Product', 'TotalVolume']].merge(monthly_block_df[['Product', 'TotalVolume']],
                                                                    on='Product', how='left').merge(
                                                                    monthly_self_match_df[['Product', 'TotalVolume']],
                                                                    on='Product', how='left').fillna(0)

    monthly_vol['Monthly ADV'] = monthly_vol.apply(lambda row: (row.TotalVolume_x + row.TotalVolume_y + row.TotalVolume) / trade_day_count, axis=1)
    return monthly_vol[['Product', 'Monthly ADV']]


def get_3_month_adv(first_day_3_month_ago, prev_day, trade_day_count, rtpl_trades, block_trades, self_match_trades):
    monthly_rtpl_df = rtpl_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")
    monthly_block_df = block_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")
    monthly_self_match_df = self_match_trades.query("SessionDate >= @first_day_of_month & SessionDate <= @prev_day")

    monthly_rtpl_df = monthly_rtpl_df.groupby(['Product'])['TotalVolume'].sum().reset_index()
    monthly_block_df = monthly_block_df.groupby(['Product'])['TotalVolume'].sum().reset_index()
    monthly_self_match_df = monthly_self_match_df.groupby(['Product'])['TotalVolume'].sum().reset_index()

    monthly_vol = monthly_rtpl_df[['Product', 'TotalVolume']].merge(monthly_block_df[['Product', 'TotalVolume']],
                                                                    on='Product', how='left').merge(
                                                                    monthly_self_match_df[['Product', 'TotalVolume']],
                                                                    on='Product', how='left').fillna(0)

    monthly_vol['Monthly ADV'] = monthly_vol.apply(lambda row: (row.TotalVolume_x + row.TotalVolume_y + row.TotalVolume) / trade_day_count, axis=1)
    return monthly_vol[['Product', 'Monthly ADV']]


def run():
    ###################################################
    #               Start - Date Logic                #
    ###################################################
    # prev_trade_date = dates.prev_trade_date()
    import pendulum
    prev_trade_date = pendulum.date(2023, 1, 19)
    td_query = get_sql_script('trading_day_table.sql', 'common/databases/sql_scripts/nymex_adv_queries', params={
        'prev_date': prev_trade_date
    })

    db_engine = cfg.get_database_engine(driver='{ODBC Driver 17 for SQL Server}',
                                        server=cfg.RTPL_SERVER,
                                        database='Common',
                                        user=cfg.OPS_SQL_USER,
                                        password=cfg.OPS_SQL_PASSWORD)

    td_df = pd.read_sql(td_query, db_engine).set_index('VARIABLE').to_dict('index')
    DATE_COUNT = td_df['DateCount']['VALUE']
    THREE_MONTH_DATE_COUNT = td_df['threemonthDateCount']['VALUE']
    TOTAL_TRADE_DAYS = td_df['total_tradedays']['VALUE']
    REMAINING_TRADE_DAYS = td_df['remain_tradedays']['VALUE']
    print(f'{DATE_COUNT} {THREE_MONTH_DATE_COUNT} {TOTAL_TRADE_DAYS} {REMAINING_TRADE_DAYS}')
    #               End - Date Logic                  #
    ###################################################
    ###################################################
    #               Start - Self Match                #
    self_match_query = get_sql_script('self_match_vol.sql', 'common/databases/sql_scripts/nymex_adv_queries', params={
        'start_date': prev_trade_date,
        'product_list': product_list
    })

    db_engine = cfg.get_database_engine(driver='{ODBC Driver 17 for SQL Server}',
                                        server=cfg.OPS_SERVER,
                                        database='Risk',
                                        user=cfg.OPS_SQL_USER,
                                        password=cfg.OPS_SQL_PASSWORD)
    self_match_df = get_self_match_agg(pd.read_sql(self_match_query, db_engine))

    #               End - Self Match                  #
    ###################################################
    ###################################################
    #               Start - Trade Data                #
    rtpl_trades_query = get_sql_script('rtpl_trades.sql', 'common/databases/sql_scripts/nymex_adv_queries', params={
        'prev_date': prev_trade_date,
        'product_list': product_list
    })

    block_trades_query = get_sql_script('block_trades.sql', 'common/databases/sql_scripts/nymex_adv_queries', params={
        'prev_date': prev_trade_date,
        'product_list': product_list
    })

    db_engine = cfg.get_database_engine(driver='{ODBC Driver 17 for SQL Server}',
                                        server=cfg.RTPL_SERVER,
                                        database='RTPL',
                                        user=cfg.OPS_SQL_USER,
                                        password=cfg.OPS_SQL_PASSWORD)

    rtpl_df = pd.read_sql(rtpl_trades_query, db_engine).sort_values(by='SessionDate', ascending=False)
    block_df = pd.read_sql(block_trades_query, db_engine).sort_values(by='SessionDate', ascending=False)

    rtpl_df['SessionDate'] = pd.to_datetime(rtpl_df['SessionDate'], format='%Y-%m-%d')
    block_df['SessionDate'] = pd.to_datetime(block_df['SessionDate'], format='%Y-%m-%d')

    # rtpl_df.to_csv('rtpl.csv', index=False)
    # block_df.to_csv('block.csv', index=False)

    ###################################################
    #               End - Trade Data                  #
    ###################################################

    ###################################################
    #           Table Metrics - Email Body            #
    ###################################################
    daily_adv = get_daily_adv(prev_trade_date, rtpl_df, block_df, self_match_df)
    monthly_adv = get_monthly_adv(dates.first_day_of_curr_month(prev_trade_date), prev_trade_date, DATE_COUNT,
                                  rtpl_df, block_df, self_match_df)

    three_month_adv = get_3_month_adv(dates.first_day_3_month_ago(prev_trade_date), prev_trade_date, DATE_COUNT,
                                  rtpl_df, block_df, self_match_df)

    print(daily_adv)
    print(monthly_adv)
    print(three_month_adv)


if __name__ == "__main__":
    run()
