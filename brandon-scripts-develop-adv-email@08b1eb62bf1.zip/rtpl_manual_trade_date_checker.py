import settings as cfg
import pyodbc as db
import pandas as pd
import common.services.date_service as dates
import common.services.email_service as emailer
from common.databases.utils import get_sql_script


def date_checker(df):
    bad_entries_col = {'FilId', 'PrdId', 'Account', 'TradeId', 'OrderId', 'FillId', 'Quantity', 'Price', 'Fee', 'Message', 'SessionDate', 'TradeSessionDate', 'LoadTime'}
    bad_entries = pd.DataFrame(columns=bad_entries_col)
    df = df.to_dict('records')
    for row in df:
        if row['SessionDate'] != row['TradeSessionDate']:
            bad_entry = {'FilId': row['FilId'],
                         'PrdId': row['PrdId'],
                         'Account': row['Account'],
                         'TradeId': row['TradeId'],
                         'OrderId': row['OrderId'],
                         'FillId': row['FillId'],
                         'Quantity': row['Quantity'],
                         'Price': row['Price'],
                         'Fee': row['Fee'],
                         'Message': row['Message'],
                         'SessionDate': row['SessionDate'],
                         'TradeSessionDate': row['TradeSessionDate'],
                         'LoadTime': row['LoadTime']}
            print(bad_entry)
            bad_entries = bad_entries.append(bad_entry, ignore_index=True)

    if not bad_entries.empty:
        alert(bad_entries[['FilId', 'PrdId', 'Account', 'TradeId', 'OrderId', 'FillId', 'Quantity', 'Price', 'Fee', 'Message', 'SessionDate', 'TradeSessionDate', 'LoadTime']])


def alert(df):
    emailer.email(df, ['bcole'])


def run():
    rtpl_trades = get_sql_script('rtpl_trade_date_checker/fill_trade_date_past_3_days.sql', params={
        'start_date': dates.past_3_bus_days()
    })

    trades_df = pd.read_sql(rtpl_trades, db.connect(cfg.conn_rtpl_test))
    date_checker(trades_df)
