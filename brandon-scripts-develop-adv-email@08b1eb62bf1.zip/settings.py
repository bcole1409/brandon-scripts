from sqlalchemy.engine import URL, create_engine

run_jobs_in_scheduler = False

# sql settings - production environments
conn_common = '''Driver={ODBC Driver 17 for SQL Server};
                       Server= CORWDP001\\GT_COMMON_1;
                       UID=sql_operations;
                       PWD=ops!gt;'''

conn_rhone = '''Driver={ODBC Driver 17 for SQL Server};
                       Server= CORWDP006\\GT_RHN_P_CHI;
                       UID=sql_operations;
                       PWD=ops!gt;'''

conn_rtpl = '''Driver={ODBC Driver 17 for SQL Server};
                       Server= CORWDP001\\GT_RTPL_P;
                       UID=sql_operations;
                       PWD=ops!gt;'''

ops_sql_engine = "mssql+pyodbc://sql_operations:ops!gt@CORWDP001\GT_COMMON_1/Operations?driver=ODBC+Driver+17+for+SQL+Server"

# test environments
conn_rtpl_test = '''Driver={ODBC Driver 17 for SQL Server};
                       Server= CORWDD001\\GT_RTPL_D;
                       UID=gtrtpl;
                       PWD=gtrtpl!;'''

OPS_SQL_USER = "sql_operations"
OPS_SQL_PASSWORD = "ops!gt"
OPS_SERVER = "CORWDP001\GT_COMMON_1"
RTPL_SERVER = "CORWDP001\GT_RTPL_P"
SQL_DRIVER = '{ODBC Driver 17 for SQL Server}'


def get_database_conn(driver: str, server: str, database: str, user: str, password: str):
    return f"DRIVER={driver};SERVER={server};DATABASE={database};UID={user};PWD={password}"


def get_database_engine(driver, server, database, user, password):
    connection_string = get_database_conn(driver, server, database, user, password)
    connection_url = URL.create("mssql+pyodbc", query={"odbc_connect": connection_string})
    engine = create_engine(connection_url)
    return engine
