import pendulum


def past_3_bus_days():
    if pendulum.today().subtract(days=1).weekday() == 6:
        return pendulum.today().subtract(days=5).date()

    if pendulum.today().subtract(days=1).weekday() == 5:
        return pendulum.today().subtract(days=4).date()

    return pendulum.today().subtract(days=3).date()


def today_date():
    return pendulum.today().date()