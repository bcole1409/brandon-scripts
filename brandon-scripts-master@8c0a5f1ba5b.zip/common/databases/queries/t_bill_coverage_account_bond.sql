Select SessionDate, OpeningBalance
  FROM [Clearing].[dbo].[ABNUS_MICS_CSVCASH_AC]
  WHERE SessionDate >= '{{rec_date}}'
  and Deleted = '0'
  and AccountId = '8740'
	AND CashTitle like '%MARK TO MARKET COVERAGE ACCT BOND%'
